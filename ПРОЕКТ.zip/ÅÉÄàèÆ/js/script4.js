const table = document.querySelector('table');
const answerContainer = document.querySelector('.answer-container');
const answers = document.querySelectorAll('.answer');
const resetButton = document.getElementById('resetButton');
const gameStatus = document.getElementById('gameStatus');

let dragging = false;
let draggedElement = null;
let cellsFilled = 0;

function calculateAnswer(row, col) {
    return row * col;
}

function checkAnswer(cell, value) {
    const row = parseInt(cell.dataset.row);
    const col = parseInt(cell.dataset.col);
    const correctAnswer = calculateAnswer(row, col);

    if (value === correctAnswer) {
        cell.classList.add('correct');
        return true;
    } else {
        cell.classList.add('incorrect');
        return false;
    }
}

function resetCell(cell) {
    cell.classList.remove('correct');
    cell.classList.remove('incorrect');
    cell.textContent = '';
}

function handleDragStart(event) {
    dragging = true;
    draggedElement = event.target;
}

function handleDragOver(event) {
    event.preventDefault();
}

function handleDrop(event) {
    event.preventDefault();

    const cell = event.target;

    if (cell.tagName === 'TD' && dragging) {
        const value = parseInt(draggedElement.dataset.value);

        if (checkAnswer(cell, value)) {
            cellsFilled++;
            // Запомнить, что элемент находится в правильном месте
            draggedElement.remove();
            cell.textContent = value;
            checkGameStatus();
        } else {
            // Возврат на место
            setTimeout(() => {
                draggedElement.style.position = 'relative';
                draggedElement.style.left = '';
                draggedElement.style.top = '';
            }, 100);
        }
    }

    dragging = false;
}

function handleDragEnd(event) {
    event.preventDefault();
    dragging = false;
    draggedElement = null;
}

function checkGameStatus() {
    if (cellsFilled === 16) {
        gameStatus.textContent = "Ура! Ты справился! Можешь попробовать еще раз!";
        gameStatus.style.color = 'green';
    }
}

function resetGame() {
    cellsFilled = 0;
    gameStatus.textContent = "";
    gameStatus.style.color = 'black';

    const cells = table.querySelectorAll('td');
    cells.forEach(cell => resetCell(cell));

    // Возвращаем ответы на место
    answers.forEach(answer => {
        answerContainer.appendChild(answer);
        answer.style.position = 'relative';
        answer.style.left = '';
        answer.style.top = '';
    });
}

// Обработчики событий для ячеек таблицы
table.addEventListener('dragover', handleDragOver);
table.addEventListener('drop', handleDrop);

// Обработчики событий для ответов
answerContainer.addEventListener('dragstart', handleDragStart);
answerContainer.addEventListener('dragend', handleDragEnd);

// Перетаскивание ответов
answers.forEach(answer => {
    answer.addEventListener('dragstart', handleDragStart);
    answer.addEventListener('dragend', handleDragEnd);

    // Обработчик клика для ответов
    answer.addEventListener('click', () => {
        if (!dragging) {
            answer.style.position = 'absolute';
            answer.style.left = event.clientX - 20 + 'px';
            answer.style.top = event.clientY - 20 + 'px';
        }
    });
});

// Очистка ячейки при клике
table.addEventListener('click', event => {
    if (event.target.tagName === 'TD' && !dragging) {
        resetCell(event.target);
    }
});

// Обработчик кнопки "Сброс"
resetButton.addEventListener('click', resetGame);
