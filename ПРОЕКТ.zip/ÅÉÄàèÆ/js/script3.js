document.addEventListener('DOMContentLoaded', function() {
  const cells = document.querySelectorAll('.cell input');
  const finishButton = document.createElement('button');
  finishButton.textContent = 'Завершить игру';
  document.querySelector('.container').appendChild(finishButton);
  
  let correctAnswers = 0;
  let wrongAnswers = 0;
  let userAnswers = [];

  cells.forEach(function(cell) {
      cell.addEventListener('input', function() {
          const correctAnswer = parseInt(cell.dataset.answer);
          const userAnswer = parseInt(cell.value);
          const index = Array.from(cells).indexOf(cell);
          if (userAnswer === correctAnswer && !userAnswers.includes(index)) {
              correctAnswers++;
              userAnswers.push(index);
          } else if (userAnswer !== correctAnswer && !userAnswers.includes(index)) {
              wrongAnswers++;
              userAnswers.push(index);
          }
      });
  });

  finishButton.addEventListener('click', function() {
      cells.forEach(function(cell, index) {
          const correctAnswer = parseInt(cell.dataset.answer);
          const userAnswer = parseInt(cell.value);
          if (userAnswer !== correctAnswer) {
              alert(`Неверный ответ: Вы ввели ${userAnswer}, правильный ответ - ${correctAnswer}`);
          }
      });
      const restartButton = document.createElement('button');
restartButton.textContent = 'Начать заново';
document.querySelector('.container').appendChild(restartButton);

restartButton.addEventListener('click', function() {
    correctAnswers = 0;
    wrongAnswers = 0;
    userAnswers = [];
    cells.forEach(function(cell) {
        cell.value = ''; // Очищаем значения ячеек ввода
    });
    alert('Игра начата заново');
});

      alert(`Правильные ответы: ${correctAnswers}, Неправильные ответы: ${wrongAnswers}`);
  });
});
