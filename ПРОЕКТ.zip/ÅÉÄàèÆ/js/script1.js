document.addEventListener('DOMContentLoaded', () => {
    const table = document.getElementById('pythagoras-table');
    const resultDiv = document.getElementById('result');
    const resultContainer = document.getElementById('result-container');
    const equationSpan = document.getElementById('equation');
    const resultImage = document.getElementById('result-image');

    const images = {
        // Добавьте картинки для каждого результата
        '1': 'images/1.png',
        '2': 'images/2.png',
        '3': 'images/3.png',
        // ... 
        '100': 'images/100.png'
    };

    for (let i = 1; i <= 10; i++) {
        const row = table.insertRow();
        for (let j = 1; j <= 10; j++) {
            const cell = row.insertCell();
            cell.textContent = i * j;
            cell.addEventListener('click', () => {
                const result = i * j;

                // Показываем уравнение
                equationSpan.textContent = `${i} x ${j} = ${result}`;

                // Устанавливаем картинку
                resultImage.src = images[result] || 'images/default.png'; // Используем картинку по умолчанию, если нет картинки для результата

                // Анимация облачка
                resultDiv.classList.remove('cloud');
                void resultDiv.offsetWidth; 
                resultDiv.classList.add('cloud');

                cell.classList.add('clicked'); 
            });
        }
    }
});